package kr.co.redbull.opt.service;

import kr.co.redbull.cmn.DTO;

public class Opt extends DTO {
	private String oNum    ;
	private String oName   ;
	private int    oPrice  ;
	private String pNum    ;
	private String iNum    ;
	
	public Opt() {}

	public Opt(String oNum, String oName, int oPrice, String pNum, String iNum) {
		super();
		this.oNum = oNum;
		this.oName = oName;
		this.oPrice = oPrice;
		this.pNum = pNum;
		this.iNum = iNum;
	}

	public String getoNum() {
		return oNum;
	}

	public void setoNum(String oNum) {
		this.oNum = oNum;
	}

	public String getoName() {
		return oName;
	}

	public void setoName(String oName) {
		this.oName = oName;
	}

	public int getoPrice() {
		return oPrice;
	}

	public void setoPrice(int oPrice) {
		this.oPrice = oPrice;
	}

	public String getpNum() {
		return pNum;
	}

	public void setpNum(String pNum) {
		this.pNum = pNum;
	}

	public String getiNum() {
		return iNum;
	}

	public void setiNum(String iNum) {
		this.iNum = iNum;
	}

	@Override
	public String toString() {
		return "Opt [oNum=" + oNum + ", oName=" + oName + ", oPrice=" + oPrice + ", pNum=" + pNum + ", iNum=" + iNum
				+ ", toString()=" + super.toString() + "]";
	}

	
}
