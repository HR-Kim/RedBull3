package kr.co.redbull.category.service;

import java.util.List;

import kr.co.redbull.cmn.DTO;

public interface CategoryService {
	/**목록조회 */
	public List<?> get_retrieve(DTO dto);

}
