package kr.co.redbull.code.service;

import java.util.List;

import kr.co.redbull.cmn.DTO;

public interface CodeService {
	public List<?> get_retrieve(DTO dto);
}
